<?php

	define('selro_url', "https://app6.selro.com/api/orders");
	define('selro_key', "9196b90e-15fa-4f6f-a6ce-9e786c499b3e");
	define('selro_secret', "91cda7b2-4847-47cb-9067-d8ae4adc86c6");
	
	define('parcelz_url', "http://api.noviship.net/v1");
	define('parcelz_key', "1e5a488ad40b3b9d3a266450021888f6");
	
	$urlParam = "?key=" . selro_key . "&secret=" . selro_secret;
	
	$data = "";
	
	
	
	$_result = callAPI("GET", $urlParam, $data);
	
	if($_result["success"] == true)
			{ 
			  echo "Success";
			  var_dump($_result);
		}
		else{
			  echo "Error";
		}
					
function callAPI($method, $urlParam, $data){

	$url = "https://reqbin.com/echo";

	$curl = curl_init($url);
	curl_setopt($curl, CURLOPT_URL, $url);
	curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);

	//for debug only!
	curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, false);
	curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);

	$resp = curl_exec($curl);
	curl_close($curl);
	var_dump($resp);
	
}

/*function callAPI($method, $urlParam, $data){
		$curl = curl_init();
		$url = selro_url . $urlParam;
		switch ($method){
			case "GET":
			  	break;
		   	case "POST":
			  	curl_setopt($curl, CURLOPT_POST, 1);
			  	if ($data)
				 	curl_setopt($curl, CURLOPT_POSTFIELDS, $data);
			  	break;
		   	case "PUT":
			  	curl_setopt($curl, CURLOPT_CUSTOMREQUEST, "PUT");
			  	if ($data)
				 	curl_setopt($curl, CURLOPT_POSTFIELDS, $data);			 					
				break;
			case "DELETE":
				curl_setopt($curl, CURLOPT_CUSTOMREQUEST, "DELETE");
				break;
		   	default:
			  	/*if ($data)
				 	$url = sprintf("%s?%s", $url, http_build_query($data));*/
		}
		/*curl_setopt($curl, CURLOPT_HTTPHEADER, array(
			"Content-type: application/json"
		));*/
		/*curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
		curl_setopt($ch, CURLOPT_HEADER, false);
		curl_setopt($curl, CURLOPT_URL, $url);
		curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
		//curl_setopt($curl, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
		
		$result = curl_exec($curl);
		$info = curl_getinfo($curl);
		
		curl_close($curl);	
		if (!$result && $info['http_code'] >= 400) {
			return array(
				"success" => false,
				"message" => "Connection Failure",
				"data" => $result
			);
		}		
		return array(
			"success" => true,
			"data" => $result
		);
	}
	*/
	

/*function get_data_from_selro(){
	
}*/
